#pragma once
#define DEGREE_H

#include <string>
using namespace std;
enum Degree { SECURITY, NETWORK, SOFTWARE };

static const string degreeTypeString[] = { "SECURITY", "NETWORK", "SOFTWARE", };





